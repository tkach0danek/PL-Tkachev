def print_digits_reverse(n):
    if n < 10:
        print(n)
    else:
        print(n % 10)
        print_digits_reverse(n // 10)

N = int(input("Введите натуральное число N: "))
print_digits_reverse(N)

